#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" app/src/main/java/br/com/discduel/LanConnection.java tests/LanSmokeTest.java
java -cp "$OUT" LanSmokeTest
