import br.com.discduel.LanConnection;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class LanSmokeTest {
    public static void main(String[] args) throws Exception {
        CountDownLatch connected = new CountDownLatch(2);
        CountDownLatch serverReceived = new CountDownLatch(1);
        CountDownLatch clientReceived = new CountDownLatch(1);
        LanConnection server = new LanConnection(new LanConnection.Listener() {
            public void onConnected() { connected.countDown(); }
            public void onMessage(String msg) { if (msg.equals("M|500.0|620.0")) serverReceived.countDown(); }
            public void onDisconnected(String reason) {}
        });
        LanConnection client = new LanConnection(new LanConnection.Listener() {
            public void onConnected() { connected.countDown(); }
            public void onMessage(String msg) { if (msg.equals("S|ok")) clientReceived.countDown(); }
            public void onDisconnected(String reason) {}
        });
        server.host();
        Thread.sleep(150);
        client.join("127.0.0.1");
        if (!connected.await(5,TimeUnit.SECONDS)) throw new AssertionError("Cannot connect");
        client.send("M|500.0|620.0");
        server.send("S|ok");
        if(!serverReceived.await(5,TimeUnit.SECONDS)) throw new AssertionError("Server lost move");
        if(!clientReceived.await(5,TimeUnit.SECONDS)) throw new AssertionError("Client lost state");
        server.close();
        client.close();
        System.out.println("OK: host/join, touch event and state over TCP loopback");
    }
}
