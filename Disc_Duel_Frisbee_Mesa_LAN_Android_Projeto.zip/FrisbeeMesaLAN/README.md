# DISC DUEL — Frisbee de Mesa LAN

Jogo **Android nativo em Java**, desenhado via Canvas, com **2 jogadores em rede local** (Wi-Fi ou hotspot), sem API, cadastro, conta, internet ou servidor externo.

## Funcionalidades

- Jogador contra BOT (single-player offline).
- Jogador contra jogador com dois celulares Android na mesma rede Wi-Fi.
- Um aparelho cria a sala e atua como servidor TCP (porta **45328**).
- O outro entra digitando o IP que aparece na parte superior da tela do anfitrião.
- Disco com inércia, rebatidas, colisões nas laterais, gols e placar. Vence o primeiro a marcar **7 gols**.
- Controle por toque/arrasto do rebatedor; cada jogador vê seu lado na parte inferior da tela.
- Sincronização do disco, dos dois rebatedores e do placar pelo anfitrião (~22 atualizações/segundo).
- Interface em português e gráficos vetoriais, sem imagens ou bibliotecas de terceiros.
- Android 7.0+ (`minSdk 24`); Android SDK 35 e Java 17 para compilação.

## Como obter o APK (sem editar código)

### Opção 1: GitHub Actions

1. Envie os arquivos deste diretório para um **repositório GitHub** com branch `main`.
2. Acesse **Actions → Gerar APK Android → Run workflow** (ou faça `push` na branch `main`).
3. Quando o workflow terminar, abra a execução e em **Artifacts** baixe **DiscDuel-APK**.
4. Extraia o ZIP do artifact: o arquivo **`app-debug.apk`** é instalável no Android.

O workflow instala JDK 17, Android SDK 35, Gradle 8.9, executa teste de TCP e compila `assembleDebug`.

### Opção 2: Android Studio

1. Instale **Android Studio**, Android SDK 35 e JDK 17.
2. Abra esta pasta como projeto Android/Gradle.
3. Use **Build → Build APK(s)** (versões recentes: **Build → Build Bundle(s) / APK(s) → Build APK(s)**).
4. APK gerado: `app/build/outputs/apk/debug/app-debug.apk`.

Ou, com **Gradle 8.9** instalado e `ANDROID_HOME` configurado:

```bash
gradle --no-daemon assembleDebug
```

O APK `debug` já é assinado pela ferramenta de desenvolvimento com chave de depuração; para publicar na Play Store é preciso gerar um release com sua própria chave.

## Como jogar em LAN

1. Conecte os **dois celulares ao mesmo Wi-Fi**. Hotspot do celular também funciona se ambos realmente estiverem na mesma rede local.
2. No aparelho A, toque **CRIAR SALA · WI-FI**. Veja o IP no topo da tela, como `192.168.1.42`.
3. No aparelho B, toque **ENTRAR EM UMA SALA** e informe exatamente esse IP.
4. Ao conectar, a partida inicia automaticamente. O disco é simulado no aparelho A, e as posições/placar são enviadas ao aparelho B.
5. Arraste seu rebatedor na metade de baixo do campo. Faça o disco entrar no gol do adversário. **7 gols vencem.**

Se não conectar: confira o IP e a rede, desligue VPN, confirme se o roteador não tem **isolamento de clientes / AP isolation** (comum em Wi-Fi público) e se a porta TCP **45328** não está bloqueada. O IP da sala pode mudar ao trocar de Wi-Fi.

## Arquitetura

```text
MainActivity.java       Menu, sala, conexão, controles de navegação
GameView.java           Canvas 2D, física, IA, placar, toque, apresentação
MenuArtView.java        Arte procedural do menu
LanConnection.java      Servidor/cliente TCP, threads de leitura, protocolo
```

Mensagens de rede em UTF-8 delimitadas por `\n`:

- Cliente → anfitrião: `M|x|y` (alvo do rebatedor do jogador visitante).
- Anfitrião → cliente: `S|discX|discY|velX|velY|bottomX|bottomY|topX|topY|scoreBottom|scoreTop|pauseSeconds|phase`.
- Cliente → anfitrião: `R` (pedido de revanche após fim da partida).

## Testes

```bash
sh tests/test-network.sh
```

O teste de integração exercita criar servidor, conectar via TCP, enviar controle do jogador e receber atualização de estado pela interface `LanConnection`.

## Observações

- Esta é uma **primeira versão jogável do projeto**. A compilação e o uso real em dois telefones Android ainda precisam ser validados em aparelhos físicos.
- Os arquivos do projeto não contêm tokens, chaves privadas ou serviços de terceiros.
- Não existe matchmaking pela internet ou descoberta automática de salas: a conexão usa IP informado manualmente.
- O jogo usa `targetSdk 35`. Ao atualizar futuramente para `targetSdk 37+`, revise a nova permissão de rede local do Android (`ACCESS_LOCAL_NETWORK`).
