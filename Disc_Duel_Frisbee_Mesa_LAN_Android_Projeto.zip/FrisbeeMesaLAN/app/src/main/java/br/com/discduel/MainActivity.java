package br.com.discduel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Locale;

public class MainActivity extends Activity implements LanConnection.Listener {
    private final int BG = Color.rgb(9, 17, 35);
    private final int WHITE = Color.rgb(243, 250, 255);
    private final int MUTED = Color.rgb(158, 179, 207);
    private final int CYAN = Color.rgb(46, 228, 255);
    private final int CORAL = Color.rgb(255, 112, 127);

    private LanConnection lan;
    private GameView game;
    private TextView statusText;
    private boolean leaving;
    private String lastIp = "192.168.1.";
    private String hostIp = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
        showMenu();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private TextView button(String value, int color, Runnable action) {
        TextView b = text(value, 16, WHITE, true);
        b.setBackground(bg(color, 17, color == BG ? Color.rgb(70, 92, 124) : 0));
        b.setPadding(dp(14), dp(17), dp(14), dp(17));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void addMargin(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        parent.addView(child, lp);
    }

    private void showMenu() {
        leaving = false;
        if (lan != null) { lan.close(); lan = null; }
        game = null;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.addView(new MenuArtView(this));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        column.setPadding(dp(30), dp(45), dp(30), dp(45));

        TextView emblem = text("◉", 76, CYAN, true);
        addMargin(column, emblem, 0);
        TextView eyebrow = text("ARCADE MULTIPLAYER", 12, MUTED, true);
        eyebrow.setLetterSpacing(.25f);
        addMargin(column, eyebrow, 2);
        TextView title = text("DISC DUEL", 43, WHITE, true);
        title.setLetterSpacing(.07f);
        addMargin(column, title, 5);
        addMargin(column, text("FRISBEE DE MESA", 14, CYAN, true), 0);
        addMargin(column, text("Arraste, rebata e marque 7 gols!", 15, MUTED, false), 19);

        addMargin(column, button("JOGAR CONTRA O BOT", Color.rgb(8, 142, 173), () -> openGame(GameView.Mode.SOLO)), 42);
        addMargin(column, button("CRIAR SALA  ·  WI-FI", Color.rgb(191, 68, 100), () -> openGame(GameView.Mode.HOST)), 13);
        addMargin(column, button("ENTRAR EM UMA SALA", Color.rgb(28, 46, 75), this::joinDialog), 13);
        TextView helper = text("2 celulares  •  mesma rede Wi-Fi  •  sem internet", 12, MUTED, false);
        addMargin(column, helper, 25);
        addMargin(column, button("COMO JOGAR  ?", BG, this::showHelp), 19);

        scroll.addView(column);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
            .setTitle("Como jogar")
            .setMessage("Mova seu rebatedor arrastando o dedo na metade inferior da mesa. Acerte o disco e faça-o atravessar o gol adversário. Ganha quem marcar 7 pontos.\n\nNo multiplayer, conecte os dois celulares à mesma rede Wi-Fi. Um jogador escolhe CRIAR SALA e informa o IP exibido; o outro seleciona ENTRAR EM UMA SALA. Não exige internet nem cadastro.\n\nA sala usa TCP na porta 45328; algumas redes públicas isolam os dispositivos e podem bloquear a conexão.")
            .setPositiveButton("ENTENDI", null).show();
    }

    private void joinDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(lastIp);
        input.setSelectAllOnFocus(true);
        input.setHint("Ex.: 192.168.1.5");
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(dp(24), dp(12), dp(24), dp(5));
        frame.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Entrar na sala")
            .setMessage("Digite o IP mostrado no celular que criou a sala.")
            .setView(frame)
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("CONECTAR", (d, w) -> {
                String ip = input.getText().toString().trim();
                if (!validIp(ip)) {
                    new AlertDialog.Builder(this).setMessage("Digite um endereço IPv4 válido, como 192.168.0.10.")
                        .setPositiveButton("OK", (a, b) -> joinDialog()).show();
                    return;
                }
                lastIp = ip;
                openGame(GameView.Mode.CLIENT);
                if (lan != null) lan.join(ip);
            }).show();
    }

    private boolean validIp(String ip) {
        String[] nums = ip.split("\\.", -1);
        if (nums.length != 4) return false;
        try {
            for (String part : nums) {
                if (part.isEmpty() || part.length() > 3 || !part.matches("[0-9]+")) return false;
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            }
        } catch (NumberFormatException ignored) { return false; }
        return true;
    }

    private void openGame(GameView.Mode mode) {
        leaving = false;
        if (lan != null) lan.close();
        lan = mode == GameView.Mode.SOLO ? null : new LanConnection(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        game = new GameView(this, mode);
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));

        TextView exit = text("‹  SAIR", 12, WHITE, true);
        exit.setBackground(bg(Color.rgb(28, 43, 67), 12, 0));
        exit.setPadding(dp(12), dp(8), dp(12), dp(8));
        exit.setOnClickListener(v -> showMenu());
        FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        exitLp.leftMargin = dp(14); exitLp.topMargin = dp(16);
        root.addView(exit, exitLp);

        statusText = text("", 12, MUTED, true);
        statusText.setBackground(bg(Color.rgb(23, 37, 58), 12, 0));
        statusText.setPadding(dp(12), dp(7), dp(12), dp(7));
        FrameLayout.LayoutParams sLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        sLp.rightMargin = dp(12); sLp.topMargin = dp(16);
        root.addView(statusText, sLp);

        setContentView(root);
        switch (mode) {
            case SOLO: statusText.setText("OFFLINE  ·  BOT"); break;
            case HOST:
                hostIp = getWifiIp();
                statusText.setText("SALA: " + hostIp);
                game.setNetworkReady(false);
                lan.host();
                break;
            case CLIENT:
                statusText.setText("CONECTANDO…");
                game.setNetworkReady(false);
                break;
        }
    }

    public String getHostIp() { return hostIp; }

    private String getWifiIp() {
        try {
            WifiManager wifi = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                int ip = wifi.getConnectionInfo().getIpAddress();
                if (ip != 0) return String.format(Locale.US, "%d.%d.%d.%d", ip & 255, (ip >> 8) & 255, (ip >> 16) & 255, (ip >> 24) & 255);
            }
        } catch (Exception ignored) { }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && addr.isSiteLocalAddress()) return addr.getHostAddress();
                }
            }
        } catch (Exception ignored) { }
        return "ver Wi-Fi";
    }

    public LanConnection getLan() { return lan; }

    @Override public void onConnected() {
        runOnUiThread(() -> {
            if (game == null || leaving) return;
            statusText.setText("●  CONECTADO");
            game.setNetworkReady(true);
        });
    }

    @Override public void onMessage(String message) {
        runOnUiThread(() -> {
            if (game != null) game.onNetMessage(message);
        });
    }

    @Override public void onDisconnected(String reason) {
        runOnUiThread(() -> {
            if (game == null || leaving) return;
            game.setNetworkReady(false);
            statusText.setText("●  SEM CONEXÃO");
            if (game.getMode() == GameView.Mode.CLIENT) {
                new AlertDialog.Builder(this).setTitle("Conexão encerrada")
                    .setMessage(reason + "\n\nConfira a rede Wi-Fi e o IP da sala.")
                    .setPositiveButton("MENU", (d, w) -> showMenu())
                    .setCancelable(false).show();
            }
        });
    }

    @Override public void onBackPressed() {
        if (game != null) showMenu(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        leaving = true;
        if (lan != null) lan.close();
        super.onDestroy();
    }
}
