package br.com.discduel;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.util.Locale;
import java.util.Random;

/**
 * Jogo 2D vetorial. O host é a fonte da verdade para colisões, tempo e placar.
 * O cliente recebe estado, posiciona seu rebatedor e envia comandos M|x|y.
 */
public final class GameView extends View {
    public enum Mode { SOLO, HOST, CLIENT }

    private static final float WIDTH = 1000f, HEIGHT = 2100f;
    private static final float LEFT = 68f, RIGHT = 932f;
    private static final float TOP = 345f, BOTTOM = 1850f;
    private static final float CENTER_Y = (TOP + BOTTOM) / 2f;
    private static final float MOUTH_L = 366f, MOUTH_R = 634f;
    private static final float DISC_R = 35f, PAD_R = 82f;
    private static final int CYAN = 0xff39e5ff, CORAL = 0xffff697e;
    private static final int WHITE = 0xffe8f9ff, TEXT_MUTED = 0xff92a9c7;

    private final Mode mode;
    private final Random random = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final Player bottom = new Player(500, 1580);
    private final Player top = new Player(500, 595);

    private float puckX = 500, puckY = CENTER_Y, puckVx = 450, puckVy = 610;
    private float angle = 0, pauseSec = 0, netSendTimer = 0, targetSendTimer = 0;
    private int scoreBottom, scoreTop, phase = 1; // 0 jogando, 1 gol/início, 2 fim
    private long lastFrameNs;
    private boolean networkReady;
    private boolean firstReady;
    private String announcement = "PREPARE-SE";
    private float offX, offY, zoom;
    private final float[][] trail = new float[11][2];

    public GameView(Context ctx, Mode mode) {
        super(ctx);
        this.mode = mode;
        this.networkReady = mode == Mode.SOLO;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        resetRound();
        setFocusable(true);
    }

    public Mode getMode() { return mode; }

    public void setNetworkReady(boolean value) {
        networkReady = value;
        if (value && !firstReady) {
            firstReady = true;
            resetMatch();
        }
        invalidate();
    }

    public void onNetMessage(String message) {
        if (mode == Mode.HOST && message.startsWith("M|")) {
            String[] a = message.split("\\|");
            if (a.length != 3) return;
            try {
                float x = Float.parseFloat(a[1]), y = Float.parseFloat(a[2]);
                if (Float.isFinite(x) && Float.isFinite(y)) {
                    top.tx = clamp(x, LEFT + PAD_R, RIGHT - PAD_R);
                    top.ty = clamp(y, TOP + PAD_R + 6, CENTER_Y - PAD_R - 12);
                }
            } catch (NumberFormatException ignored) { }
        } else if (mode == Mode.CLIENT && message.startsWith("S|")) {
            String[] a = message.split("\\|");
            if (a.length != 13) return;
            try {
                float px = Float.parseFloat(a[1]), py = Float.parseFloat(a[2]);
                float vx = Float.parseFloat(a[3]), vy = Float.parseFloat(a[4]);
                float bx = Float.parseFloat(a[5]), by = Float.parseFloat(a[6]);
                float tx = Float.parseFloat(a[7]), ty = Float.parseFloat(a[8]);
                int bs = Integer.parseInt(a[9]), ts = Integer.parseInt(a[10]);
                float delay = Float.parseFloat(a[11]);
                int state = Integer.parseInt(a[12]);
                if (!Float.isFinite(px) || !Float.isFinite(py) || !Float.isFinite(vx) || !Float.isFinite(vy)) return;
                if (Math.abs(px) > 4000 || Math.abs(py) > 4000 || Math.abs(vx) > 8000 || Math.abs(vy) > 8000) return;
                puckX = px; puckY = py; puckVx = vx; puckVy = vy;
                bottom.x = bx; bottom.y = by;
                top.x = tx; top.y = ty;
                scoreBottom = bs; scoreTop = ts; pauseSec = delay; phase = state;
                if (phase == 1) announcement = "DISCO AO CENTRO";
            } catch (NumberFormatException ignored) { }
        } else if (mode == Mode.HOST && message.equals("R")) {
            if (phase == 2) resetMatch();
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void resetMatch() {
        scoreBottom = 0; scoreTop = 0;
        bottom.set(500, 1580);
        top.set(500, 595);
        resetRound();
    }

    private void resetRound() {
        puckX = 500; puckY = CENTER_Y;
        puckVx = (random.nextFloat() - .5f) * 510;
        puckVy = (random.nextBoolean() ? 1 : -1) * 590;
        phase = 1; pauseSec = 1.25f;
        announcement = "PREPARE-SE";
        for (float[] t : trail) { t[0] = puckX; t[1] = puckY; }
    }

    private void score(boolean bottomPlayer) {
        if (bottomPlayer) scoreBottom++; else scoreTop++;
        if (scoreBottom >= 7 || scoreTop >= 7) {
            phase = 2;
            announcement = "FIM DE JOGO";
        } else {
            resetRound();
            announcement = "GOL!";
            pauseSec = 1.5f;
        }
    }

    private void update(float dt) {
        if (mode != Mode.CLIENT && networkReady) {
            updatePaddle(bottom, dt, false);
            if (mode == Mode.SOLO) {
                float aiDestination = puckY < CENTER_Y + 40 ? puckX + puckVx * .15f : 500;
                float maxStep = 690f * dt;
                top.tx += clamp(aiDestination - top.tx, -maxStep, maxStep);
                top.ty = puckY < CENTER_Y ? 585f : 650f;
            }
            updatePaddle(top, dt, true);
            if (phase == 1) {
                pauseSec -= dt;
                if (pauseSec <= 0) { phase = 0; pauseSec = 0; }
            } else if (phase == 0) {
                for (int i = trail.length - 1; i > 0; i--) {
                    trail[i][0] = trail[i-1][0]; trail[i][1] = trail[i-1][1];
                }
                trail[0][0] = puckX; trail[0][1] = puckY;
                puckX += puckVx * dt;
                puckY += puckVy * dt;
                angle += (puckVx * .003f + 3.0f) * dt;
                if (puckX - DISC_R < LEFT) {
                    puckX = LEFT + DISC_R; puckVx = Math.abs(puckVx) * .98f;
                } else if (puckX + DISC_R > RIGHT) {
                    puckX = RIGHT - DISC_R; puckVx = -Math.abs(puckVx) * .98f;
                }
                collide(bottom);
                collide(top);
                if (puckY - DISC_R <= TOP) {
                    if (puckX >= MOUTH_L && puckX <= MOUTH_R) {
                        if (puckY < TOP - DISC_R * .5f) score(true);
                    } else {
                        puckY = TOP + DISC_R;
                        puckVy = Math.abs(puckVy);
                    }
                }
                if (puckY + DISC_R >= BOTTOM) {
                    if (puckX >= MOUTH_L && puckX <= MOUTH_R) {
                        if (puckY > BOTTOM + DISC_R * .5f) score(false);
                    } else {
                        puckY = BOTTOM - DISC_R;
                        puckVy = -Math.abs(puckVy);
                    }
                }
                // Impede o disco de ficar permanentemente parado.
                float speed = (float)Math.hypot(puckVx, puckVy);
                if (speed < 340f && speed > 1f) {
                    puckVx *= 340f / speed; puckVy *= 340f / speed;
                }
            }
            if (mode == Mode.HOST) {
                netSendTimer += dt;
                if (netSendTimer >= .045f) {
                    netSendTimer = 0;
                    LanConnection peer = ((MainActivity)getContext()).getLan();
                    if (peer != null && peer.isConnected()) peer.send(String.format(Locale.US,
                        "S|%.1f|%.1f|%.1f|%.1f|%.1f|%.1f|%.1f|%.1f|%d|%d|%.2f|%d",
                        puckX, puckY, puckVx, puckVy, bottom.x, bottom.y, top.x, top.y,
                        scoreBottom, scoreTop, Math.max(0, pauseSec), phase));
                }
            }
        } else if (mode == Mode.CLIENT && networkReady) {
            angle += 5f * dt;
        }
    }

    private void updatePaddle(Player player, float dt, boolean north) {
        float minY = north ? TOP + PAD_R + 5 : CENTER_Y + PAD_R + 16;
        float maxY = north ? CENTER_Y - PAD_R - 16 : BOTTOM - PAD_R - 5;
        float oldX = player.x, oldY = player.y;
        player.tx = clamp(player.tx, LEFT + PAD_R, RIGHT - PAD_R);
        player.ty = clamp(player.ty, minY, maxY);
        float t = Math.min(1f, dt * 20f);
        player.x += (player.tx - player.x) * t;
        player.y += (player.ty - player.y) * t;
        player.vx = (player.x - oldX) / Math.max(.006f, dt);
        player.vy = (player.y - oldY) / Math.max(.006f, dt);
    }

    private void collide(Player player) {
        float dx = puckX - player.x, dy = puckY - player.y;
        float distance2 = dx * dx + dy * dy;
        float minDist = DISC_R + PAD_R - 4f;
        if (distance2 >= minDist * minDist) return;
        float distance = (float)Math.sqrt(Math.max(1f, distance2));
        float nx = dx / distance, ny = dy / distance;
        float toward = (puckVx - player.vx) * nx + (puckVy - player.vy) * ny;
        puckX = player.x + nx * (minDist + 2);
        puckY = player.y + ny * (minDist + 2);
        if (toward < 0f) {
            puckVx -= 1.85f * toward * nx;
            puckVy -= 1.85f * toward * ny;
        }
        puckVx += player.vx * .24f;
        puckVy += player.vy * .24f;
        float speed = (float)Math.hypot(puckVx, puckVy);
        if (speed > 1400f) { puckVx *= 1400f / speed; puckVy *= 1400f / speed; }
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now = System.nanoTime();
        float dt = lastFrameNs == 0 ? .016f : clamp((now - lastFrameNs) / 1_000_000_000f, 0, .033f);
        lastFrameNs = now;
        update(dt);
        paint.setShader(new LinearGradient(0, 0, 0, getHeight(), 0xff080f23, 0xff0b1b34, Shader.TileMode.CLAMP));
        c.drawColor(0xff080f23);
        c.drawRect(0, 0, getWidth(), getHeight(), paint); paint.setShader(null);
        zoom = Math.min(getWidth() / WIDTH, getHeight() / HEIGHT);
        offX = (getWidth() - WIDTH * zoom) * .5f;
        offY = (getHeight() - HEIGHT * zoom) * .5f;
        c.save(); c.translate(offX, offY); c.scale(zoom, zoom);
        c.save();
        if (mode == Mode.CLIENT) c.rotate(180f, WIDTH / 2, CENTER_Y);
        drawArena(c);
        drawTrail(c);
        drawPaddle(c, top, CORAL);
        drawPaddle(c, bottom, CYAN);
        drawPuck(c);
        c.restore();
        drawHud(c);
        drawOverlay(c);
        c.restore();
        postInvalidateOnAnimation();
    }

    private void drawArena(Canvas c) {
        rect.set(35, 320, 965, 1874);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xff0c2540);
        paint.setShadowLayer(32, 0, 0, 0x4500c8ed);
        c.drawRoundRect(rect, 55, 55, paint);
        paint.clearShadowLayer();
        rect.set(LEFT, TOP, RIGHT, BOTTOM);
        paint.setShader(new LinearGradient(0, TOP, 0, BOTTOM,
            new int[]{0xff281d38, 0xff112b43, 0xff103a4b, 0xff0a273e}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(rect, 23, 23, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xff255b70);
        c.drawRoundRect(rect, 23, 23, paint);
        paint.setStrokeWidth(3f);
        paint.setColor(0x293bc8f0);
        for (int x = 150; x < RIGHT; x += 110) c.drawLine(x, TOP + 17, x, BOTTOM - 17, paint);
        for (int y = 400; y < BOTTOM; y += 110) c.drawLine(LEFT + 17, y, RIGHT - 17, y, paint);
        paint.setColor(0xff3b697b);
        paint.setStrokeWidth(5f);
        c.drawLine(LEFT, CENTER_Y, RIGHT, CENTER_Y, paint);
        paint.setColor(0x6657d3e4);
        paint.setStrokeWidth(4f);
        c.drawCircle(500, CENTER_Y, 161, paint);
        c.drawCircle(500, CENTER_Y, 18, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x22ff8696);
        c.drawRect(LEFT + 2, TOP + 1, RIGHT - 2, TOP + 180, paint);
        paint.setColor(0x2336e5ff);
        c.drawRect(LEFT + 2, BOTTOM - 180, RIGHT - 2, BOTTOM - 1, paint);

        paint.setStrokeWidth(18f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0xff6b8fa1);
        c.drawLine(LEFT, TOP, MOUTH_L, TOP, paint);
        c.drawLine(MOUTH_R, TOP, RIGHT, TOP, paint);
        c.drawLine(LEFT, BOTTOM, MOUTH_L, BOTTOM, paint);
        c.drawLine(MOUTH_R, BOTTOM, RIGHT, BOTTOM, paint);
        paint.setColor(CORAL);
        paint.setShadowLayer(20, 0, 0, CORAL);
        c.drawLine(MOUTH_L, TOP, MOUTH_R, TOP, paint);
        paint.setColor(CYAN);
        paint.setShadowLayer(20, 0, 0, CYAN);
        c.drawLine(MOUTH_L, BOTTOM, MOUTH_R, BOTTOM, paint);
        paint.clearShadowLayer();
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStrokeWidth(1f);
    }

    private void drawPaddle(Canvas c, Player pl, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(pl.x, pl.y, PAD_R * 1.65f,
            new int[]{(color & 0x00ffffff) | 0x66000000, 0x00000000},
            null, Shader.TileMode.CLAMP));
        c.drawCircle(pl.x, pl.y, PAD_R * 1.65f, paint); paint.setShader(null);
        paint.setColor(color);
        paint.setShadowLayer(14, 0, 6, 0x88000000);
        c.drawCircle(pl.x, pl.y, PAD_R, paint);
        paint.clearShadowLayer();
        paint.setColor(0xff12283c);
        c.drawCircle(pl.x, pl.y, PAD_R - 12, paint);
        paint.setColor(color);
        c.drawCircle(pl.x, pl.y, PAD_R - 27, paint);
        paint.setColor(0x88ffffff);
        c.drawCircle(pl.x - 18, pl.y - 21, 24, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3);
        paint.setColor(0xb8ffffff);
        c.drawCircle(pl.x, pl.y, PAD_R - 4, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawTrail(Canvas c) {
        if (phase != 0) return;
        for (int i = trail.length - 1; i >= 1; i--) {
            int opacity = (int)(115 * (1f - i / (float)trail.length));
            paint.setColor((opacity << 24) | 0x00b7e9ff);
            c.drawCircle(trail[i][0], trail[i][1], DISC_R * (1f - i * .06f), paint);
        }
    }

    private void drawPuck(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x55000000);
        c.drawCircle(puckX + 7, puckY + 10, DISC_R + 5, paint);
        paint.setColor(0xffedfcff);
        paint.setShadowLayer(14, 0, 0, 0x997be1fa);
        c.drawCircle(puckX, puckY, DISC_R, paint);
        paint.clearShadowLayer();
        paint.setColor(0xff75cadb);
        c.drawCircle(puckX, puckY, DISC_R - 9, paint);
        paint.setColor(0xff174a71);
        c.drawCircle(puckX, puckY, DISC_R - 18, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffe7ffff);
        c.save(); c.rotate((float)Math.toDegrees(angle), puckX, puckY);
        c.drawArc(puckX-DISC_R+13, puckY-DISC_R+13,
            puckX+DISC_R-13, puckY+DISC_R-13, 5, 155, false, paint);
        c.drawArc(puckX-DISC_R+13, puckY-DISC_R+13,
            puckX+DISC_R-13, puckY+DISC_R-13, 185, 155, false, paint);
        c.restore();
        paint.setStyle(Paint.Style.FILL);
    }

    private void text(Canvas c, String t, float x, float y, int size, int color, boolean bold) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        paint.setTextSize(size);
        c.drawText(t, x, y, paint);
    }

    private void drawHud(Canvas c) {
        int youScore = mode == Mode.CLIENT ? scoreTop : scoreBottom;
        int themScore = mode == Mode.CLIENT ? scoreBottom : scoreTop;
        int youColor = CYAN, themColor = CORAL;
        text(c, "VOCÊ", 285, 118, 32, youColor, true);
        text(c, "RIVAL", 715, 118, 32, themColor, true);
        text(c, String.valueOf(youScore), 286, 232, 107, WHITE, true);
        text(c, "–", 499, 215, 78, 0xff4a7186, true);
        text(c, String.valueOf(themScore), 714, 232, 107, WHITE, true);
        text(c, "PRIMEIRO A 7", 500, 283, 23, TEXT_MUTED, true);
        text(c, "ARRASTE O REBATEDOR PARA DEFENDER", 500, 1973, 25, TEXT_MUTED, true);
        text(c, "DISC DUEL", 500, 2045, 23, 0xff44677e, true);
    }

    private void drawOverlay(Canvas c) {
        if (!networkReady) {
            paint.setColor(0xd5081425);
            c.drawRoundRect(115, 875, 885, 1270, 40, 40, paint);
            text(c, mode == Mode.HOST ? "SALA CRIADA" : "CONECTANDO…", 500, 972, 45, WHITE, true);
            text(c, mode == Mode.HOST ? "Informe este IP ao seu amigo:" : "Conectando ao celular anfitrião", 500, 1044, 26, TEXT_MUTED, false);
            String ip = mode == Mode.HOST ? ((MainActivity)getContext()).getHostIp() : "MESMA REDE WI-FI";
            text(c, ip, 500, 1119, mode == Mode.HOST ? 47 : 34, CYAN, true);
            text(c, "A partida começa automaticamente", 500, 1190, 26, WHITE, false);
        } else if (phase == 1) {
            paint.setColor(0xb20c1c2d);
            c.drawRoundRect(205, 958, 795, 1190, 32, 32, paint);
            text(c, announcement, 500, 1060, 57, WHITE, true);
            text(c, "PREPARE O REBATEDOR", 500, 1120, 25, CYAN, true);
        } else if (phase == 2) {
            boolean win = (mode == Mode.CLIENT ? scoreTop > scoreBottom : scoreBottom > scoreTop);
            paint.setColor(0xe00a1429);
            c.drawRoundRect(126, 856, 874, 1320, 35, 35, paint);
            text(c, win ? "VITÓRIA!" : "FIM DE JOGO", 500, 977, 70, win ? CYAN : CORAL, true);
            text(c, String.format(Locale.US, "%d  ×  %d", mode == Mode.CLIENT ? scoreTop : scoreBottom,
                    mode == Mode.CLIENT ? scoreBottom : scoreTop), 500, 1084, 62, WHITE, true);
            text(c, "TOQUE PARA JOGAR NOVAMENTE", 500, 1220, 27, WHITE, true);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action != MotionEvent.ACTION_DOWN && action != MotionEvent.ACTION_MOVE) return true;
        if (phase == 2 && action == MotionEvent.ACTION_DOWN) {
            if (mode == Mode.CLIENT) {
                LanConnection peer = ((MainActivity)getContext()).getLan();
                if (peer != null) peer.send("R");
            } else if (networkReady) resetMatch();
            return true;
        }
        if (!networkReady) return true;
        float x = (event.getX() - offX) / Math.max(.01f, zoom);
        float y = (event.getY() - offY) / Math.max(.01f, zoom);
        if (mode == Mode.CLIENT) {
            // A tela do convidado gira a mesa em 180 graus: ele joga embaixo.
            x = WIDTH - x; y = 2f * CENTER_Y - y;
            top.tx = clamp(x, LEFT + PAD_R, RIGHT - PAD_R);
            top.ty = clamp(y, TOP + PAD_R, CENTER_Y - PAD_R);
            LanConnection peer = ((MainActivity)getContext()).getLan();
            long now = System.nanoTime();
            if (peer != null && (action == MotionEvent.ACTION_DOWN || now - lastMoveSent > 25_000_000L)) {
                lastMoveSent = now;
                peer.send(String.format(Locale.US, "M|%.1f|%.1f", top.tx, top.ty));
            }
        } else {
            bottom.tx = clamp(x, LEFT + PAD_R, RIGHT - PAD_R);
            bottom.ty = clamp(y, CENTER_Y + PAD_R, BOTTOM - PAD_R);
        }
        return true;
    }

    private long lastMoveSent;
    private static final class Player {
        float x, y, tx, ty, vx, vy;
        Player(float x, float y) { set(x, y); }
        void set(float x, float y) { this.x = tx = x; this.y = ty = y; vx = vy = 0; }
    }
}
