package br.com.discduel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Conexão TCP direta entre dois dispositivos na mesma LAN. */
public final class LanConnection {
    public static final int PORT = 45328;

    public interface Listener {
        void onConnected();
        void onMessage(String message);
        void onDisconnected(String reason);
    }

    private final Listener listener;
    private volatile boolean running;
    private volatile boolean connected;
    private volatile ServerSocket server;
    private volatile Socket socket;
    private BufferedWriter writer;
    private final Object writeLock = new Object();

    public LanConnection(Listener listener) {
        this.listener = listener;
    }

    public boolean isConnected() { return connected; }

    public void host() {
        running = true;
        Thread t = new Thread(() -> {
            try {
                server = new ServerSocket(PORT);
                server.setReuseAddress(true);
                Socket accepted = server.accept();
                if (running) startSession(accepted);
                else accepted.close();
            } catch (IOException e) {
                if (running) listener.onDisconnected("Não foi possível criar a sala: " + e.getMessage());
            }
        }, "DiscDuel-Server");
        t.start();
    }

    public void join(String ip) {
        running = true;
        Thread t = new Thread(() -> {
            try {
                Socket client = new Socket();
                client.connect(new InetSocketAddress(ip, PORT), 6500);
                if (running) startSession(client);
                else client.close();
            } catch (IOException e) {
                if (running) listener.onDisconnected("Falha na conexão: " + e.getMessage());
            }
        }, "DiscDuel-Client");
        t.start();
    }

    private void startSession(Socket peer) {
        try {
            socket = peer;
            peer.setTcpNoDelay(true);
            peer.setKeepAlive(true);
            synchronized (writeLock) {
                writer = new BufferedWriter(new OutputStreamWriter(peer.getOutputStream(), StandardCharsets.UTF_8));
                connected = true;
            }
            listener.onConnected();
            BufferedReader input = new BufferedReader(new InputStreamReader(peer.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while (running && (line = input.readLine()) != null) {
                if (line.length() <= 512) listener.onMessage(line);
            }
            if (running) listener.onDisconnected("O outro jogador saiu da partida.");
        } catch (IOException e) {
            if (running) listener.onDisconnected("Conexão interrompida: " + e.getMessage());
        } finally {
            connected = false;
            close();
        }
    }

    /** Mensagens curtas; nenhum serviço de internet é utilizado. */
    public boolean send(String line) {
        if (!running || !connected || line == null || line.length() > 512) return false;
        synchronized (writeLock) {
            if (writer == null) return false;
            try {
                writer.write(line);
                writer.newLine();
                writer.flush();
                return true;
            } catch (IOException e) {
                connected = false;
                return false;
            }
        }
    }

    public void close() {
        running = false;
        connected = false;
        synchronized (writeLock) {
            writer = null;
        }
        try { if (socket != null) socket.close(); } catch (IOException ignored) { }
        try { if (server != null) server.close(); } catch (IOException ignored) { }
    }
}
