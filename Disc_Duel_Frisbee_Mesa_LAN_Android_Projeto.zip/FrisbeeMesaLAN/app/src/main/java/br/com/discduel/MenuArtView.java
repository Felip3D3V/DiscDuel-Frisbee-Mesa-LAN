package br.com.discduel;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Fundo vetorial, sem imagens externas. */
public final class MenuArtView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public MenuArtView(Context c) { super(c); }
    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        p.setShader(new LinearGradient(0, 0, w, h, 0xff0c1531, 0xff060d1e, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, p); p.setShader(null);
        float radius = Math.max(w, h) * .56f;
        p.setShader(new RadialGradient(w*.75f, h*.12f, radius,
            new int[]{0x2631b9c5, 0x10213e85, 0x000a0c26}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(w*.75f, h*.12f, radius, p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 9; i++) {
            p.setColor(i % 2 == 0 ? 0x183de0ff : 0x173df8a8);
            p.setStrokeWidth(1.3f);
            float r = w * (.30f + i * .12f);
            canvas.drawCircle(w*.87f, h*.87f, r, p);
        }
        p.setStyle(Paint.Style.FILL);
        float cx = w*.83f, cy = h*.79f;
        p.setShader(new RadialGradient(cx, cy, w*.34f,
            new int[]{0x6080f4ff, 0x0c37c5f9, 0x00000000}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, w*.34f, p); p.setShader(null);
        p.setColor(0xffb6f9ff); canvas.drawCircle(cx, cy, w*.095f, p);
        p.setColor(0xff00b7db); canvas.drawCircle(cx, cy, w*.072f, p);
        p.setColor(0xffedffff); canvas.drawCircle(cx-w*.016f, cy-w*.016f, w*.018f, p);
    }
}
